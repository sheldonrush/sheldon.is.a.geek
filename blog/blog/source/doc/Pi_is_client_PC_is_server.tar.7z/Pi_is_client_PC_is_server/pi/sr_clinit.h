

extern int socket_clinit_main(int argc, char *argv[]);
