/*
Function : Detect whether GPIO[17] is high or low
Arthur : Sheldon RUsh Peng
Date : 2013/7/27
*/

#include <wiringPi.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "sr_clinit.h" 


#define False 0
#define True 0
#define pin 0 //GPIO[17]

int main(int argc, char *argv[])
{
    int pin_value = False;
    time_t current_time;
    int count = 0;
    
    if (argc != 4)
    {
	printf("Usage : %s <ip> <port> <station id> \n", argv[0]);
        return 1;
    }
  
    if (-1 == wiringPiSetup())
	exit(1);

    // init GPIO[17] to be INPUT port 
    pinMode(pin, INPUT);
    
    while (1)
    {
        current_time = time(NULL); 
	pin_value = digitalRead(pin);
        if (True == pin_value)
	{
            count ++;
            printf("\n\n%s\n", ctime(&current_time));
	    printf("Work station call help [%d] time\n", count);
            
            if (0 != socket_clinit_main(argc,argv))
            {
	    	printf("cannot call help \n");
		return 1;
            }
	    sleep(5);
	}
    }
}
