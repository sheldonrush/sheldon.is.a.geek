/*
Function : Socket code for clinit
Arthur : SheldonRush Peng
Date : 2013/7/26
*/

#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include "sr_clinit.h"

int socket_clinit_main(int argc, char *argv[])
{
    int sockfd = 0, n = 0;
    char sendBuff[1024];

    struct sockaddr_in serv_addr;

    if (argc != 4)
    {
	printf("Usage : %s <ip> <port> <station id>\n", argv[0]);
	return 1;
    }
    
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
	printf("Error : cannot create a socket\n"); 
        return 1;
    }
    memset(sendBuff, '\0', sizeof(sendBuff));
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));

    if (inet_pton(AF_INET, argv[1], &serv_addr.sin_addr) <= 0 )
    {
	printf("%s \n" , " Error : cannot convert text to ip binary");
        return 1;
    }

    if ( connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0 )
    {
	printf("Error : canot connect server\n");
    }

    printf("Clinit: Send data to server, station id = %d\n", atoi(argv[3]));
    snprintf(sendBuff,  sizeof(sendBuff), "hi Sheldon, I am station id [%d]\n", atoi(argv[3]));
    printf("Clint: data is {%s}\n", sendBuff);
    write(sockfd, sendBuff, strlen(sendBuff));

    close(sockfd);
/*
    while ( (n = read(sockfd, recvBuff, sizeof(recvBuff)-1)) > 0)
    {
	recvBuff[n] =0;
        if ( fputs(recvBuff, stdout) == EOF)
	{
	   printf("Error : Fputs error \n");
        }
    }

   if (n < 0)
   {
	printf("Error : read error \n");
        return 1;
   }
*/
   return 0;
}
